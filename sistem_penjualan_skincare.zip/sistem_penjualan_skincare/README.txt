GLOWSTORE — Sistem Informasi Penjualan dan Stok Toko Skincare

Struktur:
- index.html
- style.css
- script.js

Cara menjalankan:
1. Ekstrak folder sistem_penjualan_skincare.zip.
2. Buka folder di Visual Studio Code.
3. Jalankan index.html dengan ekstensi Live Server, atau buka index.html langsung di browser.
4. Login menggunakan username admin dan password admin123.

Fitur:
- Login demo dan logout.
- Dashboard statistik, grafik penjualan 7 hari, stok menipis, transaksi terbaru.
- CRUD produk, pencarian, filter kategori, filter stok.
- Keranjang transaksi, validasi stok dan pembayaran, hitung total/kembalian, stok otomatis berkurang.
- CRUD pelanggan.
- Laporan dengan filter tanggal dan cetak.
- Penyimpanan localStorage.

Catatan:
- Data tersimpan pada browser/perangkat yang digunakan. Menghapus data situs/browser dapat menghapus data aplikasi.
- Login demo hanya untuk demonstrasi front-end; bukan autentikasi aman untuk penggunaan produksi.
- Grafik memakai Chart.js dari CDN sehingga membutuhkan koneksi internet untuk memuat library grafik.
