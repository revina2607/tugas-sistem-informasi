const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const STORAGE_KEY = 'glowstore_data_v1';
const rupiah = value => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(Number(value)||0);
const todayISO = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const dateLabel = value => value ? new Date(value+'T00:00:00').toLocaleDateString('id-ID',{day:'2-digit',month:'short',year:'numeric'}) : '-';
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const seed = {
  products:[
    {id:1,name:'Gentle Cleanser',category:'Cleanser',brand:'Somethinc',price:79000,stock:24},
    {id:2,name:'Hydrating Toner',category:'Toner',brand:'Skintific',price:89000,stock:18},
    {id:3,name:'Niacinamide 10% Serum',category:'Serum',brand:'The Originote',price:65000,stock:12},
    {id:4,name:'Ceramide Moisturizer',category:'Moisturizer',brand:'Skintific',price:129000,stock:8},
    {id:5,name:'Daily UV Sunscreen SPF 50',category:'Sunscreen',brand:'Azarine',price:59000,stock:30},
    {id:6,name:'Brightening Serum',category:'Serum',brand:'Avoskin',price:149000,stock:4},
    {id:7,name:'Cica Calming Gel',category:'Moisturizer',brand:'Wardah',price:47000,stock:16},
    {id:8,name:'Clay Mask Tea Tree',category:'Mask',brand:'Emina',price:32000,stock:5},
    {id:9,name:'Micellar Cleansing Water',category:'Cleanser',brand:'Garnier',price:42000,stock:21},
    {id:10,name:'AHA BHA Exfoliating Toner',category:'Toner',brand:'Avoskin',price:135000,stock:7}
  ],
  customers:[
    {id:1,name:'Nadia Putri',phone:'081234567801',email:'nadia@email.com'},
    {id:2,name:'Aulia Rahma',phone:'081234567802',email:'aulia@email.com'},
    {id:3,name:'Citra Maharani',phone:'081234567803',email:'citra@email.com'}
  ],
  transactions:[
    {id:1,date:todayISO(),customerId:1,customerName:'Nadia Putri',items:[{productId:1,name:'Gentle Cleanser',qty:1,price:79000},{productId:5,name:'Daily UV Sunscreen SPF 50',qty:1,price:59000}],total:138000,payment:150000,change:12000},
    {id:2,date:todayISO(),customerId:2,customerName:'Aulia Rahma',items:[{productId:3,name:'Niacinamide 10% Serum',qty:2,price:65000}],total:130000,payment:150000,change:20000}
  ],
  nextProductId:11,nextCustomerId:4,nextTransactionId:3
};
let data = loadData();
let cart = [];
let activePage = 'dashboard';
let chartInstance = null;
let reportTransactions = [...data.transactions];
let modalType = '';
let editingId = null;
function loadData(){
  try{
    const raw=localStorage.getItem(STORAGE_KEY);
    if(!raw){const fresh=structuredClone(seed);localStorage.setItem(STORAGE_KEY,JSON.stringify(fresh));return fresh;}
    const parsed=JSON.parse(raw);
    if(!parsed.products||!parsed.customers||!parsed.transactions) throw new Error('Data tidak lengkap');
    return parsed;
  }catch(error){console.warn('Data GlowStore tidak dapat dibaca, memakai data awal.',error);return structuredClone(seed);}
}
function saveData(){localStorage.setItem(STORAGE_KEY,JSON.stringify(data));}
function showToast(message){const toast=$('#toast');toast.textContent=message;toast.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>toast.classList.remove('show'),2600);}
function showLogin(){ $('#loginView').classList.remove('hidden');$('#appView').classList.add('hidden'); }
function showApp(){ $('#loginView').classList.add('hidden');$('#appView').classList.remove('hidden');renderAll(); }
$('#loginForm').addEventListener('submit',e=>{e.preventDefault();const user=$('#username').value.trim();const pass=$('#password').value;if(user==='admin'&&pass==='admin123'){$('#loginError').classList.add('hidden');sessionStorage.setItem('glowstore_logged_in','1');showApp();}else $('#loginError').classList.remove('hidden');});
$('#logoutBtn').addEventListener('click',()=>{sessionStorage.removeItem('glowstore_logged_in');showLogin();});
$$('.nav-link').forEach(button=>button.addEventListener('click',()=>navigate(button.dataset.page)));
$$('[data-goto]').forEach(button=>button.addEventListener('click',()=>navigate(button.dataset.goto)));
function navigate(page){activePage=page;$$('.page').forEach(el=>el.classList.add('hidden'));$(`#page-${page}`).classList.remove('hidden');$$('.nav-link').forEach(el=>el.classList.toggle('active',el.dataset.page===page));const titles={dashboard:'Dashboard',products:'Data Produk',transactions:'Transaksi Penjualan',customers:'Data Pelanggan',reports:'Laporan Penjualan'};$('#pageTitle').textContent=titles[page]||'Dashboard';$('#sidebar').classList.remove('open');if(page==='reports')applyReportFilter();if(page==='transactions')renderTransactionPage();}
$('#menuToggle').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
function renderAll(){ $('#todayLabel').textContent=new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});renderDashboard();renderProducts();renderCustomers();renderTransactionPage();applyReportFilter();populateTransactionSelects(); }
function renderDashboard(){
 const total=data.transactions.reduce((sum,t)=>sum+t.total,0);
 $('#statSales').textContent=rupiah(total);$('#statProducts').textContent=data.products.length;$('#statCustomers').textContent=data.customers.length;$('#statLowStock').textContent=data.products.filter(p=>p.stock<=5).length;
 const low=data.products.filter(p=>p.stock<=5).sort((a,b)=>a.stock-b.stock);
 $('#lowStockList').innerHTML=low.length?low.slice(0,5).map(p=>`<div class="compact-item"><div class="product-thumb">✧</div><div class="compact-info"><b>${escapeHTML(p.name)}</b><small>${escapeHTML(p.brand)} · ${escapeHTML(p.category)}</small></div><span class="stock-tag">${p.stock} unit</span></div>`).join(''):'<p class="empty-state">Semua stok dalam kondisi aman 🎉</p>';
 const recent=[...data.transactions].sort((a,b)=>b.id-a.id).slice(0,5);
 $('#recentTransactions').innerHTML=tableHTML(['ID Transaksi','Tanggal','Pelanggan','Item','Total'],recent.map(t=>[`<b>#TRX-${String(t.id).padStart(4,'0')}</b>`,dateLabel(t.date),escapeHTML(t.customerName||'Pelanggan umum'),`${t.items.reduce((s,i)=>s+i.qty,0)} unit`,`<span class="price-cell">${rupiah(t.total)}</span>`]));
 renderChart();
}
function renderChart(){
 const canvas=$('#salesChart');if(!canvas||!window.Chart)return;
 const labels=[],values=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const iso=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;labels.push(d.toLocaleDateString('id-ID',{weekday:'short'}));values.push(data.transactions.filter(t=>t.date===iso).reduce((s,t)=>s+t.total,0));}
 if(chartInstance)chartInstance.destroy();
 chartInstance=new Chart(canvas,{type:'bar',data:{labels,datasets:[{label:'Penjualan',data:values,backgroundColor:'#e9a2c4',hoverBackgroundColor:'#c88cdd',borderRadius:7,maxBarThickness:34}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>rupiah(ctx.raw)}}},scales:{x:{grid:{display:false},ticks:{color:'#a99eae'}},y:{beginAtZero:true,grid:{color:'#f1edf2'},ticks:{color:'#a99eae',callback:v=>v>=1000000?(v/1000000)+' jt':v>=1000?(v/1000)+' rb':v}}}}});
}
function tableHTML(headers,rows){if(!rows.length)return '<div class="empty-state">Belum ada data untuk ditampilkan.</div>';return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${row.map(cell=>`<td>${cell}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;}
function productStatus(stock){return stock===0?'<span class="status out">Habis</span>':stock<=5?'<span class="status low">Menipis</span>':'<span class="status good">Tersedia</span>';}
function renderProducts(){
 const q=($('#productSearch')?.value||'').trim().toLowerCase(),cat=$('#categoryFilter')?.value||'',stock=$('#stockFilter')?.value||'';
 const list=data.products.filter(p=>(`${p.name} ${p.brand} ${p.category}`.toLowerCase().includes(q))&&(!cat||p.category===cat)&&(!stock||(stock==='low'?p.stock<=5:p.stock>5)));
 $('#productsTable').innerHTML=tableHTML(['PRODUK','KATEGORI','HARGA','STOK','STATUS','AKSI'],list.map(p=>[
 `<div class="product-cell"><div class="product-thumb">✧</div><div><b>${escapeHTML(p.name)}</b><small>${escapeHTML(p.brand)}</small></div></div>`,escapeHTML(p.category),`<span class="price-cell">${rupiah(p.price)}</span>`,`${p.stock} unit`,productStatus(p.stock),
 `<div class="action-group"><button class="icon-button edit" data-edit-product="${p.id}" title="Edit">✎</button><button class="icon-button delete" data-delete-product="${p.id}" title="Hapus">×</button></div>`
 ]));
 $$('[data-edit-product]').forEach(b=>b.addEventListener('click',()=>openProductModal(Number(b.dataset.editProduct))));
 $$('[data-delete-product]').forEach(b=>b.addEventListener('click',()=>deleteProduct(Number(b.dataset.deleteProduct))));
}
$('#productSearch').addEventListener('input',renderProducts);$('#categoryFilter').addEventListener('change',renderProducts);$('#stockFilter').addEventListener('change',renderProducts);
$('#addProductBtn').addEventListener('click',()=>openProductModal());
function openProductModal(id=null){
 const p=id?data.products.find(x=>x.id===id):null;modalType='product';editingId=id;$('#modalTitle').textContent=p?'Edit Produk':'Tambah Produk';$('#modalError').classList.add('hidden');
 $('#modalFields').innerHTML=`<label>Nama Produk</label><input name="name" required maxlength="80" value="${escapeHTML(p?.name||'')}" placeholder="Contoh: Hydrating Serum"><label>Merek</label><input name="brand" required maxlength="60" value="${escapeHTML(p?.brand||'')}" placeholder="Nama merek"><label>Kategori</label><select name="category" required>${['Cleanser','Toner','Serum','Moisturizer','Sunscreen','Mask'].map(c=>`<option ${p?.category===c?'selected':''}>${c}</option>`).join('')}</select><label>Harga (Rp)</label><input name="price" type="number" min="1" step="1" required value="${p?.price??''}" placeholder="Contoh: 75000"><label>Stok</label><input name="stock" type="number" min="0" step="1" required value="${p?.stock??''}" placeholder="Contoh: 20">`;
 openModal();
}
function deleteProduct(id){const p=data.products.find(x=>x.id===id);if(!p)return;if(data.transactions.some(t=>t.items.some(i=>i.productId===id))){if(!confirm('Produk ini tercatat dalam transaksi. Hapus dari katalog? Riwayat transaksi tetap tersimpan.'))return;}else if(!confirm(`Hapus produk "${p.name}"?`))return;data.products=data.products.filter(x=>x.id!==id);cart=cart.filter(i=>i.productId!==id);saveData();renderAll();showToast('Produk berhasil dihapus.');}
function renderCustomers(){const q=($('#customerSearch')?.value||'').trim().toLowerCase();const list=data.customers.filter(c=>`${c.name} ${c.phone} ${c.email}`.toLowerCase().includes(q));$('#customersTable').innerHTML=tableHTML(['NAMA PELANGGAN','NOMOR TELEPON','EMAIL','AKSI'],list.map(c=>[ `<div class="product-cell"><div class="product-thumb">♙</div><b>${escapeHTML(c.name)}</b></div>`,escapeHTML(c.phone),escapeHTML(c.email||'-'),`<div class="action-group"><button class="icon-button edit" data-edit-customer="${c.id}" title="Edit">✎</button><button class="icon-button delete" data-delete-customer="${c.id}" title="Hapus">×</button></div>` ]));$$('[data-edit-customer]').forEach(b=>b.addEventListener('click',()=>openCustomerModal(Number(b.dataset.editCustomer))));$$('[data-delete-customer]').forEach(b=>b.addEventListener('click',()=>deleteCustomer(Number(b.dataset.deleteCustomer))));}
$('#customerSearch').addEventListener('input',renderCustomers);$('#addCustomerBtn').addEventListener('click',()=>openCustomerModal());
function openCustomerModal(id=null){const c=id?data.customers.find(x=>x.id===id):null;modalType='customer';editingId=id;$('#modalTitle').textContent=c?'Edit Pelanggan':'Tambah Pelanggan';$('#modalError').classList.add('hidden');$('#modalFields').innerHTML=`<label>Nama Lengkap</label><input name="name" required maxlength="80" value="${escapeHTML(c?.name||'')}" placeholder="Nama pelanggan"><label>Nomor Telepon</label><input name="phone" required pattern="[0-9+ -]{8,18}" value="${escapeHTML(c?.phone||'')}" placeholder="08xxxxxxxxxx"><label>Email (opsional)</label><input name="email" type="email" value="${escapeHTML(c?.email||'')}" placeholder="nama@email.com">`;openModal();}
function deleteCustomer(id){const c=data.customers.find(x=>x.id===id);if(!c||!confirm(`Hapus pelanggan "${c.name}"?`))return;data.customers=data.customers.filter(x=>x.id!==id);saveData();renderAll();showToast('Pelanggan berhasil dihapus.');}
function openModal(){$('#modalBackdrop').classList.remove('hidden');}
function closeModal(){$('#modalBackdrop').classList.add('hidden');$('#entityForm').reset();editingId=null;modalType='';}
$('#modalClose').addEventListener('click',closeModal);$('#modalCancel').addEventListener('click',closeModal);$('#modalBackdrop').addEventListener('click',e=>{if(e.target===$('#modalBackdrop'))closeModal();});
$('#entityForm').addEventListener('submit',e=>{e.preventDefault();const form=new FormData(e.currentTarget),v=Object.fromEntries(form.entries());const err=$('#modalError');err.classList.add('hidden');
 if(modalType==='product'){const price=Number(v.price),stock=Number(v.stock);if(!v.name.trim()||!v.brand.trim()||!Number.isFinite(price)||price<=0||!Number.isInteger(stock)||stock<0){err.textContent='Periksa nama, merek, harga, dan stok. Harga harus lebih dari 0 dan stok bilangan bulat minimal 0.';err.classList.remove('hidden');return;}const item={name:v.name.trim(),brand:v.brand.trim(),category:v.category,price,stock};if(editingId){Object.assign(data.products.find(p=>p.id===editingId),item);}else data.products.push({id:data.nextProductId++,...item});}
 else if(modalType==='customer'){if(!v.name.trim()||!v.phone.trim()){err.textContent='Nama dan nomor telepon wajib diisi.';err.classList.remove('hidden');return;}const item={name:v.name.trim(),phone:v.phone.trim(),email:v.email.trim()};if(editingId)Object.assign(data.customers.find(c=>c.id===editingId),item);else data.customers.push({id:data.nextCustomerId++,...item});}
 const savedType=modalType;saveData();closeModal();renderAll();showToast(savedType==='product'?'Data produk tersimpan.':'Data pelanggan tersimpan.');
});
function populateTransactionSelects(){const cust=$('#transactionCustomer').value,prod=$('#transactionProduct').value;$('#transactionCustomer').innerHTML='<option value="">Pelanggan umum</option>'+data.customers.map(c=>`<option value="${c.id}">${escapeHTML(c.name)}</option>`).join('');if(data.customers.some(c=>String(c.id)===cust))$('#transactionCustomer').value=cust;$('#transactionProduct').innerHTML='<option value="">Pilih produk...</option>'+data.products.filter(p=>p.stock>0).map(p=>`<option value="${p.id}">${escapeHTML(p.name)} — ${rupiah(p.price)} (stok ${p.stock})</option>`).join('');if(data.products.some(p=>String(p.id)===prod&&p.stock>0))$('#transactionProduct').value=prod;updateSelectedPrice();}
function updateSelectedPrice(){const p=data.products.find(p=>String(p.id)===$('#transactionProduct').value);$('#transactionPrice').value=p?rupiah(p.price):'';}
$('#transactionProduct').addEventListener('change',updateSelectedPrice);
$('#addToCartBtn').addEventListener('click',()=>{const id=Number($('#transactionProduct').value),qty=Number($('#transactionQty').value),p=data.products.find(x=>x.id===id);if(!p){showTransactionMessage('Pilih produk terlebih dahulu.');return;}if(!Number.isInteger(qty)||qty<1){showTransactionMessage('Jumlah harus berupa bilangan bulat minimal 1.');return;}const existing=cart.find(i=>i.productId===id),inCart=existing?.qty||0;if(qty+inCart>p.stock){showTransactionMessage(`Stok ${p.name} hanya ${p.stock} unit, termasuk yang sudah di keranjang.`);return;}if(existing)existing.qty+=qty;else cart.push({productId:p.id,name:p.name,qty,price:p.price});$('#transactionQty').value=1;showTransactionMessage('');renderCart();});
function renderCart(){const total=cart.reduce((s,i)=>s+i.qty*i.price,0);$('#cartCount').textContent=`${cart.reduce((s,i)=>s+i.qty,0)} unit`;$('#cartTotal').textContent=rupiah(total);$('#cartItems').innerHTML=cart.length?cart.map(i=>`<div class="cart-row"><div><b>${escapeHTML(i.name)}</b><small>${i.qty} × ${rupiah(i.price)}</small></div><span class="cart-price">${rupiah(i.qty*i.price)}</span><button class="remove-cart" data-remove-cart="${i.productId}" title="Hapus">×</button></div>`).join(''):'<p class="empty-state">Belum ada produk di keranjang.</p>';$$('[data-remove-cart]').forEach(b=>b.addEventListener('click',()=>{cart=cart.filter(i=>i.productId!==Number(b.dataset.removeCart));renderCart();updateChange();}));updateChange();}
function updateChange(){const total=cart.reduce((s,i)=>s+i.qty*i.price,0),payment=Number($('#paymentAmount').value)||0;$('#changeAmount').textContent=rupiah(Math.max(0,payment-total));}
$('#paymentAmount').addEventListener('input',updateChange);
function showTransactionMessage(message,success=false){const el=$('#transactionMessage');el.textContent=message;el.classList.toggle('success',success);}
$('#completeTransactionBtn').addEventListener('click',()=>{if(!cart.length){showTransactionMessage('Keranjang masih kosong.');return;}const total=cart.reduce((s,i)=>s+i.qty*i.price,0),payment=Number($('#paymentAmount').value);if(!Number.isFinite(payment)||payment<total){showTransactionMessage('Uang pembayaran harus sama dengan atau lebih besar dari total belanja.');return;}for(const item of cart){const p=data.products.find(p=>p.id===item.productId);if(!p||p.stock<item.qty){showTransactionMessage(`Stok ${item.name} tidak mencukupi. Periksa kembali keranjang.`);return;}}
 const customerId=Number($('#transactionCustomer').value)||null,customer=data.customers.find(c=>c.id===customerId);const transaction={id:data.nextTransactionId++,date:todayISO(),customerId,customerName:customer?.name||'Pelanggan umum',items:cart.map(i=>({...i})),total,payment,change:payment-total};cart.forEach(i=>{data.products.find(p=>p.id===i.productId).stock-=i.qty;});data.transactions.push(transaction);saveData();cart=[];$('#paymentAmount').value='';showTransactionMessage('Transaksi berhasil disimpan.',true);renderAll();showToast('Transaksi tersimpan dan stok diperbarui.');});
function renderTransactionPage(){renderCart();const list=[...data.transactions].sort((a,b)=>b.id-a.id);$('#transactionHistory').innerHTML=tableHTML(['ID TRANSAKSI','TANGGAL','PELANGGAN','JUMLAH ITEM','TOTAL'],list.map(t=>[`<b>#TRX-${String(t.id).padStart(4,'0')}</b>`,dateLabel(t.date),escapeHTML(t.customerName||'Pelanggan umum'),`${t.items.reduce((s,i)=>s+i.qty,0)} unit`,`<span class="price-cell">${rupiah(t.total)}</span>`]));}
function applyReportFilter(){if(!$('#reportsTable'))return;const start=$('#reportStart').value,end=$('#reportEnd').value;reportTransactions=data.transactions.filter(t=>(!start||t.date>=start)&&(!end||t.date<=end)).sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);const units=reportTransactions.reduce((s,t)=>s+t.items.reduce((a,i)=>a+i.qty,0),0),sales=reportTransactions.reduce((s,t)=>s+t.total,0);$('#reportCount').textContent=reportTransactions.length;$('#reportSales').textContent=rupiah(sales);$('#reportUnits').textContent=units;$('#reportsTable').innerHTML=tableHTML(['ID TRANSAKSI','TANGGAL','PELANGGAN','RINCIAN ITEM','TOTAL PENJUALAN'],reportTransactions.map(t=>[`<b>#TRX-${String(t.id).padStart(4,'0')}</b>`,dateLabel(t.date),escapeHTML(t.customerName||'Pelanggan umum'),t.items.map(i=>`${escapeHTML(i.name)} (${i.qty})`).join('<br>'),`<span class="price-cell">${rupiah(t.total)}</span>`]));}
$('#filterReportBtn').addEventListener('click',()=>{if($('#reportStart').value&&$('#reportEnd').value&&$('#reportStart').value>$('#reportEnd').value){showToast('Tanggal awal tidak boleh melebihi tanggal akhir.');return;}applyReportFilter();});
$('#resetReportBtn').addEventListener('click',()=>{$('#reportStart').value='';$('#reportEnd').value='';applyReportFilter();});
$('#printReportBtn').addEventListener('click',()=>{applyReportFilter();window.print();});
if(sessionStorage.getItem('glowstore_logged_in')==='1')showApp();else showLogin();
